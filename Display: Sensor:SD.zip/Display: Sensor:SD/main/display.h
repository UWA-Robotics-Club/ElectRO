#pragma once

#include "TFT_22_ILI9225.h"
#include <stdint.h>

// Cell structure declaration
struct Cell {
    int topLeftX, topLeftY, bottomRightX, bottomRightY;
    bool isActive = true;

    void init(int x, int y, int w, int h);
};

// External access to the display object
extern TFT_22_ILI9225 tft;

// Function declarations
void initializeGrid(Cell* grid, uint8_t* numRows, uint8_t* numCols, uint8_t* cellWidth, uint8_t* cellHeight);
void mergeCells(Cell* grid, uint8_t* gridCols, uint8_t startCol, uint8_t startRow, uint8_t endCol, uint8_t endRow, uint8_t* cellWidth, uint8_t* cellHeight);
void drawGrid(Cell* grid, uint8_t* gridRows, uint8_t* gridCols, bool draw);
void drawTextInCell(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, const char* text);
void drawImageInCellBW(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, const uint8_t* imageData, int imageWidth, int imageHeight, uint16_t color, uint16_t bg);
void drawImageInCellColor(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, const uint16_t* imageData, int imageWidth, int imageHeight);
void clearCell(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, uint16_t bgColor);
void beginDisplay(Cell* grid, uint8_t* numRows, uint8_t* numCols, uint8_t* cellWidth, uint8_t* cellHeight);
