#include "display.h"
#include <SPI.h>
#include <SD.h>
#include "TFT_22_ILI9225.h"

#define TFT_RST 8
#define TFT_RS  9
#define TFT_CS  10
#define TFT_SDI 41  // Mega MOSI
#define TFT_CLK 42  // Mega SCK
#define TFT_LED 3
#define TFT_BRIGHTNESS 200

// SOFTWARE SPI constructor — REQUIRED for Arduino Mega
TFT_22_ILI9225 tft = TFT_22_ILI9225(
    TFT_RST, TFT_RS, TFT_CS,
    TFT_SDI, TFT_CLK,
    TFT_LED, TFT_BRIGHTNESS);


void beginDisplay(Cell* grid, uint8_t* numRows, uint8_t* numCols, uint8_t* cellWidth, uint8_t* cellHeight) {
    // Reset the display hardware
    pinMode(TFT_RST, OUTPUT);
    digitalWrite(TFT_RST, LOW);
    delay(50);
    digitalWrite(TFT_RST, HIGH);
    delay(50);

    // Reclaim SPI bus
    SPI.begin();  // Ensures we're in control again after SD messed with it

  // Begin TFT again — this is crucial!
    tft.begin();
    tft.setOrientation(1);
    tft.setFont(Terminal6x8);

    *cellWidth = tft.maxX() / (*numCols);
    *cellHeight = tft.maxY() / (*numRows);

    initializeGrid(grid, numRows, numCols, cellWidth, cellHeight);
}


void Cell::init(int x, int y, int w, int h) {
    topLeftX = x;
    topLeftY = y;
    bottomRightX = x + w;
    bottomRightY = y + h;
    isActive = true;
}

void initializeGrid(Cell* grid, uint8_t* numRows, uint8_t* numCols, uint8_t* cellWidth, uint8_t* cellHeight) {
    for (uint8_t row = 0; row < (*numRows); ++row) {
        for (uint8_t col = 0; col < (*numCols); ++col) {
            int index = row * (*numCols) + col;
            grid[index].init(col * (*cellWidth), row * (*cellHeight), (*cellWidth), (*cellHeight));
        }
    }
}

void mergeCells(Cell* grid, uint8_t* gridCols, uint8_t startCol, uint8_t startRow, uint8_t endCol, uint8_t endRow,  uint8_t* cellWidth,  uint8_t* cellHeight) {
    int index = startRow * (*gridCols) + startCol;

    // Deactivate merged-over cells
    for (uint8_t row = startRow; row <= endRow; ++row) {
        for (uint8_t col = startCol; col <= endCol; ++col) {
            int i = row * (*gridCols) + col;
            grid[i].isActive = false;
        }
    }

    // Activate only one merged cell
    grid[index].topLeftX = startCol * (*cellWidth);
    grid[index].topLeftY = startRow * *(cellHeight);
    grid[index].bottomRightX = (endCol + 1) * (*cellWidth);
    grid[index].bottomRightY = (endRow + 1) * (*cellHeight);
    grid[index].isActive = true;
}

void drawGrid(Cell* grid, uint8_t* gridRows, uint8_t* gridCols, bool draw) {
    for (uint8_t i = 0; i < (*gridRows) * (*gridCols); ++i) {
        if (!grid[i].isActive) continue;
        Cell& cell = grid[i];

        uint16_t COLOR;
        if(draw){
          COLOR = COLOR_WHITE;
        }
        else{
          COLOR = COLOR_BLACK;
        }
        tft.drawLine(cell.topLeftX, cell.topLeftY, cell.bottomRightX, cell.topLeftY, COLOR); // Top
        tft.drawLine(cell.topLeftX, cell.topLeftY, cell.topLeftX, cell.bottomRightY, COLOR); // Left
        tft.drawLine(cell.bottomRightX, cell.topLeftY, cell.bottomRightX, cell.bottomRightY, COLOR); // Right
        tft.drawLine(cell.topLeftX, cell.bottomRightY, cell.bottomRightX, cell.bottomRightY, COLOR); // Bottom
    }
}

void drawTextInCell(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, const char* text) {
    uint16_t index = row * (*gridCols) + col;
    Cell cell = grid[index];
    if (!cell.isActive) return;

    int cellWidth = cell.bottomRightX - cell.topLeftX;
    int cellHeight = cell.bottomRightY - cell.topLeftY;

    const uint8_t fontWidth = 6;  // Terminal6x8 font
    const uint8_t fontHeight = 8;

    // Calculate maximum characters per line and max number of lines
    uint8_t maxCharsPerLine = cellWidth / fontWidth;
    uint8_t maxLines = cellHeight / fontHeight;

    // Prepare a buffer to hold words
    char buffer[128];
    strncpy(buffer, text, sizeof(buffer));
    buffer[sizeof(buffer) - 1] = '\0';

    // Break into words and build lines
    char* word = strtok(buffer, " ");
    String lines[maxLines];
    uint8_t lineIndex = 0;

    while (word && lineIndex < maxLines) {
        if (lines[lineIndex].length() + strlen(word) <= maxCharsPerLine) {
            if (lines[lineIndex].length() > 0) lines[lineIndex] += " ";
            lines[lineIndex] += word;
        } else {
            lineIndex++;
            if (lineIndex >= maxLines) break;
            lines[lineIndex] += word;
        }
        word = strtok(NULL, " ");
    }

    // Vertical centering
    int totalTextHeight = (lineIndex + 1) * fontHeight;
    int startY = cell.topLeftY + (cellHeight - totalTextHeight) / 2;

    // Draw each line
    for (int i = 0; i <= lineIndex; i++) {
        int lineLength = lines[i].length();
        int lineWidth = lineLength * fontWidth;
        int x = cell.topLeftX + (cellWidth - lineWidth) / 2;
        int y = startY + i * fontHeight;

        tft.drawText(x, y, lines[i].c_str());
    }
}


void drawImageInCellBW(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, const uint8_t* imageData, int imageWidth, int imageHeight, uint16_t color, uint16_t bg) {
    uint16_t index = row * (*gridCols) + col;
    Cell cell = grid[index];
    int x = cell.topLeftX + 2;
    int y = cell.topLeftY + (cell.bottomRightY - cell.topLeftY - imageHeight) / 2;

    tft.drawBitmap(x, y, imageData, imageWidth, imageHeight, color, bg);
}

void drawImageInCellColor(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, const uint16_t* imageData, int imageWidth, int imageHeight) {
    uint16_t index = row * (*gridCols) + col;
    Cell& cell = grid[index];
    int x = cell.topLeftX + 2;
    int y = cell.topLeftY + (cell.bottomRightY - cell.topLeftY - imageHeight) / 2;

    tft.drawBitmap(x, y, imageData, imageWidth, imageHeight);
}

void clearCell(Cell* grid, uint8_t* gridCols, uint8_t col, uint8_t row, uint16_t bgColor) {
    uint16_t index = row * (*gridCols) + col;
    Cell cell = grid[index];

    // If the cell is active, clear the area
    if (cell.isActive) {
        tft.fillRectangle(cell.topLeftX+1, cell.topLeftY+1, cell.bottomRightX-1, cell.bottomRightY-1, bgColor);
    }
}

