#ifndef SDHELPER_H
#define SDHELPER_H

#include <Arduino.h>

// Declare your functions here
String getVariableValue(const char* fileName, const String& varName);
void writeToFile(const char* fileName, const char* content);
void readFromFile(const char* fileName);
bool initializeSDCard(); // Returns true on success, false on failure
#endif
