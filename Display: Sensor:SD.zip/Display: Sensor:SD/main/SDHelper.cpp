#include <SD.h>
#include "SDHelper.h"

const int chipSelect = 22;
#define TFT_CS 10

String getVariableValue(const char* fileName, const String& varName) {
  File file = SD.open(fileName);
  if (!file) {
    Serial.print("Could not open file: ");
    Serial.println(fileName);
    return "";
  }

  String line = "";
  while (file.available()) {
    char c = file.read();
    if (c == '\n' || c == '\r') {
      line.trim();
      line.replace(" ", "");

      if (line.startsWith(varName + "=")) {
        int eqIndex = line.indexOf('=');
        int semicolonIndex = line.indexOf(';');
        if (eqIndex >= 0 && semicolonIndex > eqIndex) {
          String value = line.substring(eqIndex + 1, semicolonIndex);
          file.close();
          return value;
        }
      }
      line = "";
    } else {
      line += c;
    }
  }

  file.close();
  return "";
}

void writeToFile(const char* fileName, const char* content) {
  SD.remove(fileName); // Clear previous content

  File file = SD.open(fileName, FILE_WRITE);
  if (file) {
    Serial.print("Writing to ");
    Serial.println(fileName);

    int bytesWritten = file.println(content);
    Serial.print("Bytes Written: ");
    Serial.println(bytesWritten);

    file.close();
    Serial.println("Write complete.");
  } else {
    Serial.print("Error opening ");
    Serial.println(fileName);
  }
}

void readFromFile(const char* fileName) {
  File file = SD.open(fileName);
  if (file) {
    Serial.print("Reading from ");
    Serial.println(fileName);
    while (file.available()) {
      char c = file.read();
      Serial.print(c);
    }
    file.close();
    Serial.println("\nRead complete.");
  } else {
    Serial.print("Error opening ");
    Serial.println(fileName);
  }
}

// MODIFIED FUNCTION IMPLEMENTATION: Now halts on failure
bool initializeSDCard() {
  Serial.println("Initializing SD card...");
  delay(10); // Small delay for stability

  if (!SD.begin(chipSelect)) {
    Serial.println("SD card initialization failed! System halted.");
    while (true); // Halt execution here if SD card fails
    return false; // This line is technically unreachable but good practice
  }
  Serial.println("SD card initialized.");
  return true; // Indicate success
}
