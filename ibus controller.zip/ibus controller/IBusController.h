#ifndef IBUSCONTROLLER_H
#define IBUSCONTROLLER_H

#include <Arduino.h>
#include <IBusBM.h>

// External iBus object so .ino can initialize it
extern IBusBM ibus;

// Function declarations
int readChannel(byte channelInput, int minLimit, int maxLimit, int defaultValue);
bool readSwitch(byte channelInput, bool defaultValue);
int* ibuscontroller();

#endif
