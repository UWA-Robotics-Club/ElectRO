#include "IBusController.h"

// Define the iBus object here
IBusBM ibus;

int readChannel(byte channelInput, int minLimit, int maxLimit, int defaultValue) {
    uint16_t ch = ibus.readChannel(channelInput);
    if (ch < 100) return defaultValue;
    return map(ch, 1000, 2000, minLimit, maxLimit);
}

bool readSwitch(byte channelInput, bool defaultValue) {
    int intDefaultValue = (defaultValue) ? 100 : 0;
    int ch = readChannel(channelInput, 0, 100, intDefaultValue);
    return (ch > 50);
}

int* ibuscontroller() {
    static int sensors[6]; // static so it persists outside the function

    for (byte i = 0; i < 5; i++) {
        sensors[i] = readChannel(i, -100, 100, 0);
    }
    sensors[5] = readSwitch(5, false) ? 1 : 0;

    return sensors;
}
